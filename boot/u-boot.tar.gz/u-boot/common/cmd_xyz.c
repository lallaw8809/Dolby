#include <common.h>
#include <command.h>
#include <environment.h>
#include <linux/stddef.h>
#include <malloc.h>

int do_xyz (cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])
{
 ulong addr, rc=1;
 int     rcode = 0;

 if (argc < 2) {
  printf ("Usage:%s", cmdtp->help);
  return 1;
 }
 printf("\nArgument = %s",argv[1]);
 printf ("\n## Application Successfuly run & terminated\n");
 return rcode;
}

U_BOOT_CMD(
 xyz, 2, 1, do_xyz,
 "xyz  -- sample command  application\n",
 "\nusage xyz arg     - dispaly argument\n"
);

