#include <common.h>
#include <command.h>
#include <environment.h>
#include <linux/stddef.h>
#include <malloc.h>

int do_arvi (cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])
{
 ulong addr, rc=1;
 int     rcode = 0;

 if (argc < 2) {
  printf ("Usage:%s", cmdtp->help);
  return 1;
 }
 printf("\nArgument = %s",argv[1]);
 printf ("\n## Application Successfuly run & terminated\n");
 return rcode;
}

U_BOOT_CMD(
 arvi, 2, 1, do_arvi,
 "arvi -- sample command  application\n",
 "\n Arvind is configuring and porting u-boot bootlader on ARM Board\n"
);

